# ChallengeLiteratura
Challenge e literatura dentro de la formacion de ALURA
        MENU PRINCIPAL 
                --------------------------------------------
                1 - Buscar Libros por TÍtulo
                2 - Buscar Autor por Nombre
                3 - Listar Libros Registrados
                4 - Listar Autores Registrados
                5 - Listar Autores Vivos
                6 - Listar Libros por Idioma
                7 - Buscar Libros por TÍtulo BULK
                8 - Top 10 Libros más Buscados
                9 - Generar Estadísticas
                ----------------------------------------------
                0 -  SALIR DEL PROGRAMA 
                ---------------------------------------------
                Elija una opción:

1) busca un libro en funcion de coincidencia parcial de una palbra del titulo
2) busca autor en la base en funcion de la coincidencia de una parte del nombre
3) lista libros en la base
4) Idem 3 autores
5) en funcion de un año erstablece que autores estaban vivos y su edad en ese año
6) busca los idiomas que existen en la base y debes seleccionar las siglas para encontrat los libros
7) ingresa todos los libros encontrados verificando que no existan ya ni autor ni libro
8) se autoexplica
9) mayor numero de sdescargas, menos numero de descargas y descargas medias.

Features. Se ha creado en el objeto libro el campo de topicos o tematica que se extrae de la descripcion de las tematicas, en funcion de 3 basicas (DRAMA,COMEDIA,FICCION) en caso de no existir pone OTRA.
La salida para el usuario no es la mas amigable pero creo que todo funciona.


